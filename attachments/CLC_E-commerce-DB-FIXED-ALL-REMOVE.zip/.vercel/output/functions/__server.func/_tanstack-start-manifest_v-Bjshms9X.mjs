//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bjshms9X.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/cart",
			"/checkout",
			"/help",
			"/login",
			"/order-success",
			"/orders",
			"/prescription",
			"/shop",
			"/track",
			"/wishlist",
			"/admin/customers",
			"/admin/orders",
			"/admin/prescriptions",
			"/admin/products",
			"/admin/stock",
			"/product/$slug",
			"/admin/"
		],
		preloads: [
			"/assets/index-CDfVUfb7.js",
			"/assets/store-zGtOPNWZ.js",
			"/assets/preload-helper-ra6Xzs7v.js",
			"/assets/useNavigate-D2EPzopY.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CDfVUfb7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-LL_d2-jc.js",
			"/assets/Layout-BAz9wH2C.js",
			"/assets/ProductCard-Pn88fe1-.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CHKvXE2m.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/cart": {
		filePath: "/workspace/src/routes/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-BSYzOrpN.js",
			"/assets/Layout-BAz9wH2C.js",
			"/assets/ProductCard-Pn88fe1-.js"
		]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-C6h2n7TW.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/help": {
		filePath: "/workspace/src/routes/help.tsx",
		children: void 0,
		preloads: ["/assets/help-0au2B6My.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-CddiioGF.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/order-success": {
		filePath: "/workspace/src/routes/order-success.tsx",
		children: void 0,
		preloads: ["/assets/order-success-DQuEcwU5.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/orders": {
		filePath: "/workspace/src/routes/orders.tsx",
		children: void 0,
		preloads: ["/assets/orders-CUiJaaoj.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/prescription": {
		filePath: "/workspace/src/routes/prescription.tsx",
		children: void 0,
		preloads: ["/assets/prescription-OgD-BGFk.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: void 0,
		preloads: [
			"/assets/shop-BcAu6wmF.js",
			"/assets/Layout-BAz9wH2C.js",
			"/assets/ProductCard-Pn88fe1-.js"
		]
	},
	"/track": {
		filePath: "/workspace/src/routes/track.tsx",
		children: void 0,
		preloads: ["/assets/track-C9HYiFOV.js", "/assets/Layout-BAz9wH2C.js"]
	},
	"/wishlist": {
		filePath: "/workspace/src/routes/wishlist.tsx",
		children: void 0,
		preloads: [
			"/assets/wishlist-BbwQU5FL.js",
			"/assets/Layout-BAz9wH2C.js",
			"/assets/ProductCard-Pn88fe1-.js"
		]
	},
	"/admin/customers": {
		filePath: "/workspace/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-syFOhNIB.js", "/assets/AdminLayout-DQsAQBOo.js"]
	},
	"/admin/orders": {
		filePath: "/workspace/src/routes/admin/orders.tsx",
		children: void 0,
		preloads: ["/assets/orders-C1gplM2i.js", "/assets/AdminLayout-DQsAQBOo.js"]
	},
	"/admin/prescriptions": {
		filePath: "/workspace/src/routes/admin/prescriptions.tsx",
		children: void 0,
		preloads: ["/assets/prescriptions-BY-vc_Ea.js", "/assets/AdminLayout-DQsAQBOo.js"]
	},
	"/admin/products": {
		filePath: "/workspace/src/routes/admin/products.tsx",
		children: void 0,
		preloads: ["/assets/products-ytuNb2Ji.js", "/assets/AdminLayout-DQsAQBOo.js"]
	},
	"/admin/stock": {
		filePath: "/workspace/src/routes/admin/stock.tsx",
		children: void 0,
		preloads: ["/assets/stock-G0y_dAs5.js", "/assets/AdminLayout-DQsAQBOo.js"]
	},
	"/product/$slug": {
		filePath: "/workspace/src/routes/product.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/product._slug-DgVu5H0Q.js",
			"/assets/Layout-BAz9wH2C.js",
			"/assets/ProductCard-Pn88fe1-.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin/index.tsx",
		children: void 0,
		preloads: ["/assets/admin-CGVBkuZr.js", "/assets/AdminLayout-DQsAQBOo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
