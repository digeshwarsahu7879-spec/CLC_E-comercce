import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as statusClass, l as formatINR, m as useClc, p as statusLabel } from "./store-CV2HDjfH.mjs";
import { m as Check } from "../_libs/lucide-react.mjs";
import { t as Layout } from "./Layout-9I4ksX97.mjs";
import { a as Route$12 } from "./router-CX4U3bLO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-success-G8GtGeDd.js
var import_jsx_runtime = require_jsx_runtime();
function OrderSuccessPage() {
	const { id } = Route$12.useSearch();
	const order = useClc((s) => s.orders).find((o) => o.id === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "container-clc",
		children: !order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "empty-cart",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Order not found" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/orders",
				className: "btn btn-primary",
				children: "My orders"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "success-hero",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "success-icon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 32 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Order placed successfully" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: order.method === "upi" ? "Payment is in process. Our team will verify your UPI payment and confirm the order." : "Your COD order is confirmed. We’ll pack and ship it soon." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					style: {
						fontWeight: 600,
						color: "var(--color-ink)"
					},
					children: ["Order ID: ", order.id]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						flexWrap: "wrap",
						gap: 10,
						justifyContent: "center",
						marginTop: 20
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/orders",
							className: "btn btn-primary",
							children: "View my orders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/track",
							search: { id: order.id },
							className: "btn btn-ghost",
							children: "Track order"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop",
							search: {
								cat: "",
								q: ""
							},
							className: "btn btn-ghost",
							children: "Continue shopping"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			style: {
				maxWidth: 560,
				margin: "0 auto 48px",
				padding: 20
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "summary-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `status-pill ${statusClass(order.status)}`,
						children: statusLabel(order.status)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "summary-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Payment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: order.method === "upi" ? "UPI QR" : "Cash on Delivery" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "summary-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatINR(order.total) }) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "summary-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Deliver to" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						order.customer.name,
						", ",
						order.customer.city
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						marginTop: 12,
						fontSize: "0.875rem",
						color: "var(--color-muted)"
					},
					children: order.items.map((i) => `${i.name} × ${i.qty}`).join(" · ")
				})
			]
		})] })
	}) });
}
//#endregion
export { OrderSuccessPage as component };
