import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CV2HDjfH.js
var CATEGORIES = [
	{
		slug: "medicines",
		name: "Medicines",
		desc: "Fever, pain & digestion",
		image: "/images/cat-medicines.jpg"
	},
	{
		slug: "healthcare",
		name: "Healthcare",
		desc: "Home recovery care",
		image: "/images/cat-healthcare.jpg"
	},
	{
		slug: "personal-care",
		name: "Personal Care",
		desc: "Daily hygiene",
		image: "/images/cat-personal.jpg"
	},
	{
		slug: "baby-care",
		name: "Baby Care",
		desc: "Gentle baby essentials",
		image: "/images/cat-baby.jpg"
	},
	{
		slug: "ayurveda",
		name: "Ayurveda",
		desc: "Herbal wellness",
		image: "/images/cat-ayurveda.jpg"
	},
	{
		slug: "vitamins",
		name: "Vitamins",
		desc: "Daily nutrition",
		image: "/images/cat-vitamins.jpg"
	},
	{
		slug: "surgical",
		name: "Surgical",
		desc: "Dressings & kits",
		image: "/images/cat-surgical.jpg"
	},
	{
		slug: "health-devices",
		name: "Devices",
		desc: "Home monitoring",
		image: "/images/cat-devices.jpg"
	}
];
/** Public seed catalog shown on the storefront. Admins can still add, edit, or hide items. */
function item(id, slug, name, brand, cat, price, extra = {}) {
	const catName = CATEGORIES.find((c) => c.slug === cat)?.name || cat;
	const old = extra.old ?? Math.round(price * 1.28);
	return {
		id,
		slug,
		name,
		brand,
		cat,
		catName,
		price,
		old,
		off: extra.off ?? Math.max(0, Math.round((1 - price / old) * 100)),
		stock: extra.stock ?? 48,
		tone: extra.tone || "tone-moss",
		rx: extra.rx ?? false,
		pack: extra.pack || "Strip of 10",
		desc: extra.desc || name,
		ingredients: extra.ingredients || "",
		directions: extra.directions || "Use as directed on the pack, or ask your pharmacist.",
		image: extra.image
	};
}
var PRODUCTS = [
	item("p_para650", "paracetamol-650", "Paracetamol 650 mg", "CLC Care", "medicines", 32, {
		tone: "tone-moss",
		pack: "Strip of 15 tablets",
		desc: "For fever and mild to moderate pain. Fast, gentle relief for everyday use.",
		ingredients: "Paracetamol 650 mg",
		directions: "Adults: 1 tablet every 6–8 hours if needed. Do not exceed 4 tablets in 24 hours."
	}),
	item("p_ibupro", "ibuprofen-400", "Ibuprofen 400 mg", "CLC Care", "medicines", 48, {
		tone: "tone-teal",
		pack: "Strip of 10 tablets",
		desc: "Anti-inflammatory relief for headaches, body ache and period pain.",
		ingredients: "Ibuprofen 400 mg"
	}),
	item("p_ceti", "cetirizine-10", "Cetirizine 10 mg", "CLC Allergy", "medicines", 22, {
		tone: "tone-sage",
		pack: "Strip of 10 tablets",
		desc: "Once-daily tablet for sneezing, runny nose and itchy eyes.",
		ingredients: "Cetirizine hydrochloride 10 mg"
	}),
	item("p_ors", "ors-orange", "ORS Orange Sachets", "CLC Hydrate", "medicines", 18, {
		old: 24,
		tone: "tone-brown",
		pack: "Box of 10 sachets",
		desc: "WHO-formula oral rehydration salts for dehydration from heat or stomach upset.",
		ingredients: "Sodium, potassium, chloride, citrate, glucose"
	}),
	item("p_antacid", "antacid-gel", "Antacid Gel Mint", "CLC Digest", "medicines", 95, {
		tone: "tone-teal",
		pack: "170 ml bottle",
		desc: "Soothing mint gel for acidity, heartburn and gas.",
		ingredients: "Aluminium hydroxide, magnesium hydroxide, simethicone"
	}),
	item("p_cough", "cough-relief-syrup", "Cough Relief Syrup", "CLC Relief", "medicines", 78, {
		tone: "tone-moss",
		pack: "100 ml bottle",
		desc: "Honey-soothing syrup for dry and chesty cough.",
		ingredients: "Dextromethorphan, guaifenesin, flavoured base"
	}),
	item("p_thermo", "digital-thermometer", "Digital Thermometer", "CLC Devices", "healthcare", 149, {
		old: 199,
		tone: "tone-slate",
		pack: "1 unit",
		desc: "Quick-read oral thermometer with a clear display for home use."
	}),
	item("p_hotbag", "hot-water-bag", "Hot Water Bag", "CLC Comfort", "healthcare", 189, {
		tone: "tone-brown",
		pack: "2 litre",
		desc: "Rubber hot-water bag for muscle stiffness and winter warmth."
	}),
	item("p_steam", "steam-vaporizer", "Steam Vaporizer", "CLC Comfort", "healthcare", 449, {
		old: 599,
		tone: "tone-teal",
		pack: "1 unit",
		desc: "Electric steam vaporizer for blocked nose and dry rooms."
	}),
	item("p_cotton", "sterile-cotton-100g", "Sterile Cotton Roll", "CLC Clinic", "healthcare", 55, {
		tone: "tone-sage",
		pack: "100 g",
		desc: "Soft sterile cotton for first aid and baby care."
	}),
	item("p_sani", "hand-sanitizer-500", "Hand Sanitizer 500 ml", "CLC Clean", "personal-care", 129, {
		old: 159,
		tone: "tone-teal",
		pack: "500 ml pump",
		desc: "70% alcohol sanitizer that dries quickly without a sticky feel."
	}),
	item("p_moist", "daily-moisturiser", "Daily Moisturising Cream", "CLC Skin", "personal-care", 165, {
		tone: "tone-sage",
		pack: "100 g jar",
		desc: "Light, non-greasy cream for dry hands and everyday skin care."
	}),
	item("p_antiseptic", "antiseptic-liquid", "Antiseptic Liquid", "CLC Clean", "personal-care", 89, {
		tone: "tone-moss",
		pack: "100 ml",
		desc: "Dilute for cuts, grazes and household first aid."
	}),
	item("p_babylotion", "baby-lotion", "Gentle Baby Lotion", "CLC Baby", "baby-care", 175, {
		tone: "tone-sage",
		pack: "200 ml",
		desc: "Mild, fragrance-light lotion for delicate baby skin."
	}),
	item("p_babysoap", "baby-soap", "Baby Cleansing Bar", "CLC Baby", "baby-care", 65, {
		tone: "tone-brown",
		pack: "75 g",
		desc: "Soap-free bar that rinses clean and does not sting the eyes."
	}),
	item("p_triphala", "triphala-tablets", "Triphala Tablets", "CLC Ayurveda", "ayurveda", 135, {
		tone: "tone-brown",
		pack: "Bottle of 60",
		desc: "Classic herbal blend used to support daily digestion.",
		ingredients: "Amalaki, bibhitaki, haritaki"
	}),
	item("p_tulsi", "tulsi-drops", "Tulsi Drops", "CLC Ayurveda", "ayurveda", 99, {
		tone: "tone-moss",
		pack: "30 ml",
		desc: "Holy basil extract drops to mix in warm water or tea.",
		ingredients: "Ocimum sanctum extract"
	}),
	item("p_vitc", "vitamin-c-500", "Vitamin C 500 mg", "CLC Nutri", "vitamins", 149, {
		old: 199,
		tone: "tone-moss",
		pack: "Bottle of 60",
		desc: "Daily vitamin C to support immunity and skin health.",
		ingredients: "Ascorbic acid 500 mg"
	}),
	item("p_multi", "daily-multivitamin", "Daily Multivitamin", "CLC Nutri", "vitamins", 249, {
		tone: "tone-teal",
		pack: "Bottle of 30",
		desc: "Once-a-day vitamins and minerals for busy routines."
	}),
	item("p_cal", "calcium-d3", "Calcium + Vitamin D3", "CLC Nutri", "vitamins", 189, {
		tone: "tone-slate",
		pack: "Strip of 15",
		desc: "Bone-support tablets with calcium and vitamin D3."
	}),
	item("p_band", "waterproof-bandages", "Waterproof Bandages", "CLC Clinic", "surgical", 45, {
		tone: "tone-sage",
		pack: "Pack of 20",
		desc: "Stay-on strips for cuts and kitchen nicks.",
		image: "/images/waterproof-bandage.svg"
	}),
	item("p_firstaid", "first-aid-kit", "Home First Aid Kit", "CLC Clinic", "surgical", 399, {
		old: 499,
		tone: "tone-moss",
		pack: "1 kit",
		desc: "Bandages, antiseptic, gauze and tape for the home cupboard."
	}),
	item("p_gauze", "gauze-pads", "Sterile Gauze Pads", "CLC Clinic", "surgical", 72, {
		tone: "tone-slate",
		pack: "Pack of 10",
		desc: "Individually wrapped pads for dressing small wounds."
	}),
	item("p_bp", "bp-monitor", "Blood Pressure Monitor", "CLC Devices", "health-devices", 1299, {
		old: 1599,
		tone: "tone-slate",
		pack: "1 unit",
		desc: "Upper-arm BP monitor with a large display for home checks."
	}),
	item("p_oxi", "pulse-oximeter", "Pulse Oximeter", "CLC Devices", "health-devices", 799, {
		old: 999,
		tone: "tone-teal",
		pack: "1 unit",
		desc: "Fingertip meter for pulse and oxygen saturation."
	})
];
/** Admin login only (not shown on the login page). */
var DEMO_USERS = [{
	email: "admin@clc.com",
	password: "admin123",
	name: "CLC Administrator",
	role: "admin"
}];
var UPI_ID = "7879522683@ybl";
var SUPPORT_PHONE = "+91 78795 22683";
var SUPPORT_EMAIL = "support@curelifecare.in";
function formatINR(n) {
	return "₹" + Number(n).toLocaleString("en-IN");
}
function slugify(text) {
	return String(text || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "product";
}
function getProduct(slugOrId, list = PRODUCTS) {
	return list.find((p) => p.slug === slugOrId || p.id === slugOrId);
}
function getCategory(slug) {
	return CATEGORIES.find((c) => c.slug === slug);
}
function uid() {
	return "CLC-" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
}
function productId() {
	return "p_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function statusLabel(s) {
	return {
		payment_pending: "Payment in process",
		confirmed: "Confirmed",
		shipped: "Shipped",
		delivered: "Delivered",
		cancelled: "Cancelled"
	}[s] || s;
}
function statusClass(s) {
	if (s === "delivered") return "status-ok";
	if (s === "cancelled") return "status-bad";
	if (s === "payment_pending") return "status-warn";
	return "status-info";
}
function shippingFor(subtotal) {
	return subtotal >= 499 ? 0 : 40;
}
var toastTimer = null;
function mergeCatalog(custom, edits, deleted) {
	const deletedSet = new Set(deleted);
	const base = PRODUCTS.filter((p) => !deletedSet.has(p.id)).map((p) => {
		const e = edits[p.id];
		return e ? {
			...p,
			...e,
			id: p.id
		} : p;
	});
	const extras = custom.filter((p) => !deletedSet.has(p.id)).map((p) => {
		const e = edits[p.id];
		return e ? {
			...p,
			...e,
			id: p.id
		} : p;
	});
	return [...base, ...extras];
}
var useClc = create()(persist((set, get) => ({
	cart: {},
	wish: [],
	orders: [],
	user: null,
	stock: {},
	customProducts: [],
	productEdits: {},
	deletedProductIds: [],
	prescriptions: [],
	toast: null,
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	showToast: (msg) => {
		set({ toast: msg });
		if (toastTimer) clearTimeout(toastTimer);
		toastTimer = setTimeout(() => set({ toast: null }), 2200);
	},
	listProducts: () => {
		const s = get();
		return mergeCatalog(s.customProducts, s.productEdits, s.deletedProductIds);
	},
	findProduct: (slugOrId) => {
		return getProduct(slugOrId, get().listProducts());
	},
	getStock: (id) => {
		const overrides = get().stock;
		if (Object.prototype.hasOwnProperty.call(overrides, id)) return Math.max(0, Number(overrides[id]) || 0);
		const p = get().findProduct(id);
		return p ? p.stock : 0;
	},
	setStock: (id, qty) => {
		const n = Math.max(0, Math.floor(Number(qty) || 0));
		set((s) => ({ stock: {
			...s.stock,
			[id]: n
		} }));
		return n;
	},
	adjustStock: (id, delta) => {
		const next = Math.max(0, get().getStock(id) + delta);
		return get().setStock(id, next);
	},
	resetStock: () => set({ stock: {} }),
	addProduct: (input) => {
		const name = (input.name || "").trim();
		const brand = (input.brand || "").trim() || "CLC";
		const cat = (input.cat || "medicines").trim();
		const catName = (input.catName || cat).trim();
		const price = Math.max(0, Number(input.price) || 0);
		const old = Math.max(price, Number(input.old) || price);
		const off = input.off != null ? Math.max(0, Math.min(99, Math.floor(Number(input.off) || 0))) : old > price ? Math.round((old - price) / old * 100) : 0;
		const stock = Math.max(0, Math.floor(Number(input.stock) ?? 0));
		let slug = slugify(input.slug || name);
		if (get().listProducts().some((p) => p.slug === slug)) slug = slug + "-" + Date.now().toString(36).slice(-4);
		const product = {
			id: productId(),
			slug,
			name: name || "Untitled product",
			brand,
			cat,
			catName,
			price,
			old,
			off,
			stock,
			tone: input.tone || "",
			rx: Boolean(input.rx),
			pack: (input.pack || "1 unit").trim(),
			desc: (input.desc || "").trim(),
			ingredients: (input.ingredients || "").trim(),
			directions: (input.directions || "").trim(),
			image: (input.image || "").trim() || void 0
		};
		set((s) => ({
			customProducts: [...s.customProducts, product],
			stock: {
				...s.stock,
				[product.id]: stock
			}
		}));
		get().showToast("Product added");
		return product;
	},
	updateProduct: (id, input) => {
		const current = get().findProduct(id);
		if (!current) return null;
		const next = {};
		if (input.name != null) next.name = String(input.name).trim() || current.name;
		if (input.brand != null) next.brand = String(input.brand).trim() || current.brand;
		if (input.cat != null) {
			next.cat = String(input.cat).trim();
			next.catName = (input.catName || input.cat).trim();
		} else if (input.catName != null) next.catName = String(input.catName).trim();
		if (input.price != null) next.price = Math.max(0, Number(input.price) || 0);
		if (input.old != null) next.old = Math.max(0, Number(input.old) || 0);
		if (input.off != null) next.off = Math.max(0, Math.min(99, Math.floor(Number(input.off) || 0)));
		if (input.tone != null) next.tone = String(input.tone);
		if (input.rx != null) next.rx = Boolean(input.rx);
		if (input.pack != null) next.pack = String(input.pack).trim();
		if (input.desc != null) next.desc = String(input.desc).trim();
		if (input.ingredients != null) next.ingredients = String(input.ingredients).trim();
		if (input.directions != null) next.directions = String(input.directions).trim();
		if (input.image != null) next.image = String(input.image).trim() || void 0;
		if (input.slug != null) {
			let slug = slugify(input.slug);
			if (get().listProducts().some((p) => p.slug === slug && p.id !== id)) slug = slug + "-" + Date.now().toString(36).slice(-4);
			next.slug = slug;
		}
		if (input.stock != null) get().setStock(id, Number(input.stock));
		if (get().customProducts.some((p) => p.id === id)) set((s) => ({ customProducts: s.customProducts.map((p) => p.id === id ? {
			...p,
			...next
		} : p) }));
		else set((s) => ({ productEdits: {
			...s.productEdits,
			[id]: {
				...s.productEdits[id] || {},
				...next
			}
		} }));
		get().showToast("Product updated");
		return get().findProduct(id) || null;
	},
	removeProduct: (id) => {
		set((s) => {
			const isCustom = s.customProducts.some((p) => p.id === id);
			const customProducts = isCustom ? s.customProducts.filter((p) => p.id !== id) : s.customProducts;
			const deletedProductIds = isCustom ? s.deletedProductIds : s.deletedProductIds.includes(id) ? s.deletedProductIds : [...s.deletedProductIds, id];
			const cart = { ...s.cart };
			delete cart[id];
			const wish = s.wish.filter((x) => x !== id);
			const stock = { ...s.stock };
			delete stock[id];
			const productEdits = { ...s.productEdits };
			delete productEdits[id];
			return {
				customProducts,
				deletedProductIds,
				cart,
				wish,
				stock,
				productEdits
			};
		});
		get().showToast("Product removed");
	},
	addToCart: (id, qty = 1) => {
		const stock = get().getStock(id);
		const cart = { ...get().cart };
		const current = cart[id] || 0;
		const add = Math.max(1, qty);
		if (stock < 1) {
			get().showToast("Out of stock");
			return false;
		}
		if (current + add > stock) {
			get().showToast(`Only ${stock} in stock`);
			if (current >= stock) return false;
			cart[id] = stock;
		} else cart[id] = current + add;
		set({ cart });
		const p = get().findProduct(id);
		get().showToast(p ? `Added “${p.name}” to cart` : "Added to cart");
		return true;
	},
	setQty: (id, qty) => {
		const cart = { ...get().cart };
		if (qty <= 0) delete cart[id];
		else {
			const stock = get().getStock(id);
			cart[id] = Math.min(qty, Math.max(stock, 0));
			if (qty > stock) get().showToast(stock < 1 ? "Out of stock" : `Only ${stock} in stock`);
		}
		set({ cart });
	},
	removeFromCart: (id) => {
		const cart = { ...get().cart };
		delete cart[id];
		set({ cart });
		get().showToast("Removed from cart");
	},
	clearCart: () => set({ cart: {} }),
	toggleWish: (id) => {
		const wish = get().wish;
		if (wish.includes(id)) {
			set({ wish: wish.filter((x) => x !== id) });
			get().showToast("Removed from wishlist");
			return false;
		}
		set({ wish: [...wish, id] });
		get().showToast("Saved to wishlist");
		return true;
	},
	login: (email, password) => {
		const emailNorm = (email || "").trim().toLowerCase();
		const found = DEMO_USERS.find((u) => u.email === emailNorm && u.password === password);
		if (found) {
			const user = {
				email: found.email,
				name: found.name,
				role: found.role
			};
			set({ user });
			return {
				ok: true,
				user
			};
		}
		if (emailNorm && password && password.length >= 4) {
			const user = {
				email: emailNorm,
				name: emailNorm.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
				role: "customer"
			};
			set({ user });
			return {
				ok: true,
				user
			};
		}
		return {
			ok: false,
			error: "Invalid email or password"
		};
	},
	register: (name, email, password) => {
		const emailNorm = (email || "").trim().toLowerCase();
		if (!name || !emailNorm || !password || password.length < 4) return {
			ok: false,
			error: "Please fill all fields (password min 4 chars)"
		};
		if (DEMO_USERS.some((u) => u.email === emailNorm)) return {
			ok: false,
			error: "That email is reserved — try logging in"
		};
		const user = {
			email: emailNorm,
			name: name.trim(),
			role: "customer"
		};
		set({ user });
		return {
			ok: true,
			user
		};
	},
	logout: () => set({ user: null }),
	placeOrder: (payload) => {
		const items = payload.items || [];
		items.forEach((item) => get().adjustStock(item.id, -(item.qty || 0)));
		const order = {
			id: uid(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			status: payload.status || (payload.method === "upi" ? "payment_pending" : "confirmed"),
			method: payload.method,
			total: payload.total,
			subtotal: payload.subtotal,
			shipping: payload.shipping,
			items,
			customer: payload.customer
		};
		set((s) => ({
			orders: [order, ...s.orders],
			cart: {}
		}));
		return order;
	},
	setOrderStatus: (id, status) => {
		set((s) => {
			return { orders: s.orders.map((o) => {
				if (o.id !== id) return o;
				if (status === "cancelled" && o.status !== "cancelled") o.items.forEach((item) => get().adjustStock(item.id, item.qty || 0));
				return {
					...o,
					status
				};
			}) };
		});
	},
	addPrescription: (fileName, sizeKb) => {
		const rx = {
			id: uid(),
			fileName,
			sizeKb,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			status: "pending",
			customerName: get().user?.name || "Guest"
		};
		set((s) => ({ prescriptions: [rx, ...s.prescriptions] }));
		get().showToast("Prescription submitted");
		return rx;
	},
	setPrescriptionStatus: (id, status) => {
		set((s) => ({ prescriptions: s.prescriptions.map((p) => p.id === id ? {
			...p,
			status
		} : p) }));
	}
}), {
	name: "clc-store",
	partialize: (s) => ({
		cart: s.cart,
		wish: s.wish,
		orders: s.orders,
		user: s.user,
		stock: s.stock,
		customProducts: s.customProducts,
		productEdits: s.productEdits,
		deletedProductIds: s.deletedProductIds,
		prescriptions: s.prescriptions
	}),
	version: 2,
	migrate: (persisted) => {
		const p = persisted ?? {};
		return {
			cart: p.cart && typeof p.cart === "object" ? p.cart : {},
			wish: Array.isArray(p.wish) ? p.wish : [],
			orders: Array.isArray(p.orders) ? p.orders : [],
			user: p.user ?? null,
			stock: p.stock && typeof p.stock === "object" ? p.stock : {},
			customProducts: Array.isArray(p.customProducts) ? p.customProducts : [],
			productEdits: p.productEdits && typeof p.productEdits === "object" ? p.productEdits : {},
			deletedProductIds: Array.isArray(p.deletedProductIds) ? p.deletedProductIds : [],
			prescriptions: Array.isArray(p.prescriptions) ? p.prescriptions : []
		};
	},
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			...p,
			cart: p.cart && typeof p.cart === "object" ? p.cart : {},
			wish: Array.isArray(p.wish) ? p.wish : [],
			orders: Array.isArray(p.orders) ? p.orders : [],
			stock: p.stock && typeof p.stock === "object" ? p.stock : {},
			customProducts: Array.isArray(p.customProducts) ? p.customProducts : [],
			productEdits: p.productEdits && typeof p.productEdits === "object" ? p.productEdits : {},
			deletedProductIds: Array.isArray(p.deletedProductIds) ? p.deletedProductIds : [],
			prescriptions: Array.isArray(p.prescriptions) ? p.prescriptions : []
		};
	},
	onRehydrateStorage: () => () => {
		useClc.getState().setHydrated();
	}
}));
function cartCount(cart) {
	return Object.values(cart).reduce((s, q) => s + q, 0);
}
function cartItems(cart, getStock) {
	const products = useClc.getState().listProducts();
	return Object.entries(cart).map(([id, qty]) => {
		const p = products.find((x) => x.id === id);
		if (!p) return null;
		return {
			...p,
			qty,
			stock: getStock(id),
			lineTotal: p.price * qty
		};
	}).filter(Boolean);
}
function cartTotals(items) {
	const subtotal = items.reduce((s, i) => s + i.lineTotal, 0);
	const shipping = shippingFor(subtotal);
	return {
		subtotal,
		shipping,
		total: subtotal + shipping
	};
}
function liveProduct(slugOrId, getStock) {
	const p = useClc.getState().findProduct(slugOrId);
	if (!p) return null;
	return {
		...p,
		stock: getStock(p.id)
	};
}
//#endregion
export { UPI_ID as a, cartTotals as c, liveProduct as d, statusClass as f, SUPPORT_PHONE as i, formatINR as l, useClc as m, PRODUCTS as n, cartCount as o, statusLabel as p, SUPPORT_EMAIL as r, cartItems as s, CATEGORIES as t, getCategory as u };
